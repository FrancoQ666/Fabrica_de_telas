// server.js
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
// Crea Socket.IO en el mismo server HTTP
const io = new Server(server);

// Servir carpeta public
app.use(express.static('public'));

// Evento de conexión
io.on('connection', (socket) => {
  if (io.sockets.sockets.size > 200) {
    socket.emit('system', 'Servidor con alta carga. Posibles delays.');
  }
  console.log('Nuevo cliente conectado:', socket.id);

  socket.on('join', ({ username, room }) => {
    socket.data.username = username || 'Anon';
    socket.data.room = room;
    socket.join(room);
    // Avisar a la sala
    socket.to(room).emit('system', `${socket.data.username} se ha unido a la sala.`);
    // Enviar confirmación al que se unió
    socket.emit('system', `Conectado como ${socket.data.username} en la sala "${room}".`);
  });

  socket.on('message', (text) => {
    const room = socket.data.room;
    const username = socket.data.username || 'Anon';
    if (!room) return; // si no se unió a una sala, ignorar
    const payload = {
      username,
      text,
      time: new Date().toISOString()
    };
    // Emitir a todos en la sala (incluye al emisor)
    io.to(room).emit('message', payload);
  });

  socket.on('disconnect', () => {
    const username = socket.data.username;
    const room = socket.data.room;
    if (username && room) {
      socket.to(room).emit('system', `${username} se ha desconectado.`);
    }
    console.log('Cliente desconectado:', socket.id);
  });
});

// Escuchar en 0.0.0.0 para que sea accesible desde la red local
const PORT = process.env.PORT || 3000;
server.listen(PORT, '130.10.1.23', () => {
  console.log(`Servidor escuchando en http://130.10.1.23:${PORT}`);
});
