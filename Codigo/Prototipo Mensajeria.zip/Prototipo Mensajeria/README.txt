Bueno, aqui basicamente cuando de el aviso que funcione el server, ingresen por este enlace: http://130.10.1.23:3000

Ahi, estaran como un menu de crear usuario(Simplemente un nombre y sala) ingresen su nombre y ingrese en la parte de sala "1"(UNO!, Sala: "1") 

