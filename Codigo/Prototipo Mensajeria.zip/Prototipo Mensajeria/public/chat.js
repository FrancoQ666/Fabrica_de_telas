// chat.js
const socket = io();

const joinBox = document.getElementById('joinBox');
const chatBox = document.getElementById('chatBox');
const joinBtn = document.getElementById('joinBtn');
const usernameInput = document.getElementById('username');
const roomInput = document.getElementById('room');
const headerInfo = document.getElementById('headerInfo');
const messagesDiv = document.getElementById('messages');
const msgInput = document.getElementById('msgInput');
const sendBtn = document.getElementById('sendBtn');

function appendMessage(html, klass = '') {
  const el = document.createElement('div');
  el.className = 'message ' + klass;
  el.innerHTML = html;
  messagesDiv.appendChild(el);
  messagesDiv.scrollTop = messagesDiv.scrollHeight;
}

joinBtn.addEventListener('click', () => {
  const username = usernameInput.value.trim() || 'Anon';
  const room = roomInput.value.trim() || 'general';
  socket.emit('join', { username, room });
  joinBox.classList.add('hidden');
  chatBox.classList.remove('hidden');
  headerInfo.textContent = `Conectado como ${username} — Sala: ${room}`;
  msgInput.focus();
});

sendBtn.addEventListener('click', () => {
  const text = msgInput.value.trim();
  if (!text) return;
  socket.emit('message', text);
  msgInput.value = '';
  msgInput.focus();
});

// Enviar con Enter
msgInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') sendBtn.click();
});

socket.on('system', (txt) => {
  appendMessage(`<em>${escapeHtml(txt)}</em>`, 'system');
});

socket.on('message', ({ username, text, time }) => {
  const shortTime = new Date(time).toLocaleTimeString();
  appendMessage(`<strong>${escapeHtml(username)}</strong> <span class="time">${shortTime}</span><div class="txt">${escapeHtml(text)}</div>`, 'chat');
});

function escapeHtml(s) {
  return s.replace(/[&<>"']/g, (m) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
}
